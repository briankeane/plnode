'use strict';

// Use local.env.js for environment variables that grunt will set when the server starts locally.
// Use for your api keys, secrets, etc. This file should not be tracked by git.
//
// You will need to set these on the server you deploy to.

module.exports = {
  DOMAIN: 'http://localhost:9000',
  SESSION_SECRET: "pl2nodeyo-secret",

  TWITTER_ID: 'bPCzqjjUVQu00WYg53vPBKip6',
  TWITTER_SECRET: 'lCDUKUo1HTSDou8eKLaaRccHAihUeHJUySaX27hcOtg5Xtrs4V',

  AWS_ACCESS_KEY_ID: 'AKIAI6WPOTSYWAV6LXQQ',
  AWS_SECRET_ACCESS_KEY: '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',

  ECHONEST_KEY: '1EFRD4YMEN003A4N1',
  ECHONEST_CONSUMER_KEY: '4c51bc0f2cbd6007a4d1e5025fd0c75f',
  ECHONEST_SHARED_SECRET: 'CDb/ITdgR0GT9mKHOq+tKQ',

  // Control debug level for modules using visionmedia/debug
  DEBUG: ''
};
